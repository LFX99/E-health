
from skimage import io,transform
import glob
import os
import tensorflow as tf
import numpy as np
import time

#path = '/Users/zhangyue/Desktop/光照/颜色性状5/性状/'
path='E:/Dataset/Feces/ALL3/'
#将所有的图片resize成100*100
w=200
h=200
c=3


#读取图片
def read_img(path):
    cate=[path+x for x in os.listdir(path) if os.path.isdir(path+x)]
    imgs=[]
    labels=[]
    for idx,folder in enumerate(cate):
        for im in glob.glob(folder+'/*.jpg'):
            print('reading the images:%s'%(im))
            img=io.imread(im)
            img=transform.resize(img,(w,h))
            imgs.append(img)
            labels.append(idx)
    return np.asarray(imgs,np.float32),np.asarray(labels,np.int32)
data,label=read_img(path)
#data2,label2=read_img(path2)

#打乱顺序
num_example=data.shape[0]
arr=np.arange(num_example)
np.random.shuffle(arr)
data=data[arr]
label=label[arr]


#将所有数据分为训练集和验证集
ratio=0.7
s=np.int(num_example*ratio)
x_train=data[:s]
y_train=label[:s]
x_val=data[s:]
y_val=label[s:]

#-----------------构建网络----------------------
#占位符
x=tf.placeholder(tf.float32,shape=[None,w,h,c],name='x') #这里的none就是batch.size
y_=tf.placeholder(tf.int32,shape=[None,],name='y_')

#第一个卷积层（100——>50)
conv1=tf.layers.conv2d(
      inputs=x,
      filters=32,
      kernel_size=[5, 5],
      padding="same",
      activation=tf.nn.relu,
      kernel_initializer=tf.truncated_normal_initializer(stddev=0.01))
pool1=tf.layers.max_pooling2d(inputs=conv1, pool_size=[2, 2], strides=2)

#第二个卷积层(50->25)
conv2=tf.layers.conv2d(
      inputs=pool1,
      filters=64,#卷积和的数量
      kernel_size=[5, 5],
      padding="same",
      activation=tf.nn.relu,
      kernel_initializer=tf.truncated_normal_initializer(stddev=0.01))
pool2=tf.layers.max_pooling2d(inputs=conv2, pool_size=[2, 2], strides=2)

re1 = tf.reshape(pool2, [-1, 50 * 50 * 64])#这里为什么要50x50？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？


dense2= tf.layers.dense(inputs=re1, 
                      units=256,#这里为什么是256？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
                      activation=tf.nn.relu,
                      kernel_initializer=tf.truncated_normal_initializer(stddev=0.01),
                      kernel_regularizer=tf.contrib.layers.l2_regularizer(0.003))
logits= tf.layers.dense(inputs=dense2, 
                        units=3,
                        activation=None,
                        kernel_initializer=tf.truncated_normal_initializer(stddev=0.01),
                        kernel_regularizer=tf.contrib.layers.l2_regularizer(0.003))        #为什么会有两个全连接层？
#---------------------------网络结束---------------------------


#定义一个函数，按批次取数据
def minibatches(inputs=None, targets=None, batch_size=None, shuffle=False):#minibatch的目的原理
    assert len(inputs) == len(targets)  #assert后面的语句不成立就弹出AssertionError
    if shuffle:
        indices = np.arange(len(inputs)) #生成有start end stride的排列
        np.random.shuffle(indices)#打乱序列
    for start_idx in range(0, len(inputs) - batch_size + 1, batch_size):#把乱序的下表indice生成不同的minibatch的下标
        if shuffle:
            excerpt = indices[start_idx:start_idx + batch_size]
        else:
            excerpt = slice(start_idx, start_idx + batch_size)
        yield inputs[excerpt], targets[excerpt]


#训练和测试数据，可将n_epoch设置更大一些
n_epoch=10
batch_size=3 # 越小越快，
gpu_options = tf.GPUOptions(per_process_gpu_memory_fraction=0.5)
sess = tf.Session(config=tf.ConfigProto(gpu_options=gpu_options, log_device_placement=True))#建立会话，并且配置
sess.run(tf.global_variables_initializer())
#writer =tf.summary.FileWriter("logs/0pre_0.25/", sess.graph)# 日志文件，58行修改为0.7,0.5,0.25
i=1
for epoch in range(n_epoch):
    
    start_time = time.time()
    
    #training
    train_loss, train_acc, n_batch = 0, 0, 0
    
    for x_train_a, y_train_a in minibatches(x_train, y_train, batch_size, shuffle=True):
        _,err,ac=sess.run([train_op,loss,acc], feed_dict={x: x_train_a, y_: y_train_a})#训练的到error 和accuracy的数据
        train_loss += err; train_acc += ac; n_batch += 1
        
    result = sess.run(loss1,feed_dict={x: x_train_a, y_: y_train_a})
    result1 = sess.run(acc1,feed_dict={x: x_train_a, y_: y_train_a})
    writer.add_summary(result,epoch)
    writer.add_summary(result1,epoch)
    print("   train loss: %f" % (train_loss/ n_batch))
    print("   train acc: %f" % (train_acc/ n_batch))
    
    
    #validation
    val_loss, val_acc, n_batch = 0, 0, 0
    for x_val_a, y_val_a in minibatches(x_val, y_val, batch_size, shuffle=False):
        err, ac = sess.run([loss,acc], feed_dict={x: x_val_a, y_: y_val_a})
        val_loss += err; val_acc += ac; n_batch += 1
    result2 = sess.run(loss2,feed_dict={x: x_val_a, y_: y_val_a})
    result3 = sess.run(acc2,feed_dict={x: x_val_a, y_: y_val_a})
    writer.add_summary(result2,epoch)
    writer.add_summary(result3,epoch)
    print("   validation loss: %f" % (val_loss/ n_batch))
    print("   validation acc: %f" % (val_acc/ n_batch))
    i=i+1
     

sess.close()