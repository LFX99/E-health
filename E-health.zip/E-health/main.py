# -*- coding: utf-8 -*-
"""
Created on Fri Jun  5 13:20:21 2020

@author: Young
"""


#https://blog.csdn.net/mao_hui_fei/article/details/84801620


import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'



from skimage import io,transform
import glob
import os
import tensorflow as tf
import numpy as np
import time

#数据集地址
path=      'E:/Demo/Python/STOOL/feces/'
#模型保存地址
model_path='E:/Demo/Python/STOOL/MODEL/model.ckpt'

#将所有的图片resize成100*100
w=100
h=100
c=3


#读取图片
def read_img(path):                                                   #把path中的图片读出来并且resize，得到的结果添加在列表的末尾
    cate=[path+x for x in os.listdir(path) if os.path.isdir(path+x)]  #cate为path中所有的元素组成的元组
                                                                      # os.listdir(path)--列出path下所有的文件
    imgs=[]
    labels=[]
    for idx,folder in enumerate(cate):                                #返回 enumerate(枚举) 对象
        for im in glob.glob(folder+'/*.jpg'):                         #glob 文件名模式匹配，不用遍历整个目录判断每个文件是不是符合
            print('reading the images:%s'%(im))
            img=io.imread(im)
            img=transform.resize(img,(w,h))                           #resize
            imgs.append(img)                                          #append() 方法用于在列表末尾添加新的对象。
            labels.append(idx)
    return np.asarray(imgs,np.float32),np.asarray(labels,np.int32)    #将目标变量整合成array
data,label=read_img(path)


#打乱顺序
num_example=data.shape[0]                                             #data.shape[0]取行数data.shape[1]去列数
arr=np.arange(num_example)                                            #生成一个序列， num_example为序列的长度--在这里用做生成index
np.random.shuffle(arr)                                                #将生成的index打乱
data=data[arr]                                                        #python中想把data乱序排列就是这个样子
label=label[arr]


#将所有数据分为训练集和验证集
ratio=0.8                                                             #
s=np.int(num_example*ratio)                                           #声明数组
x_train=data[:s]
y_train=label[:s]
x_val=data[s:]
y_val=label[s:]

#-----------------构建网络----------------------
#占位符
x=tf.placeholder(tf.float32,shape=[None,w,h,c],name='x')              #用于传入外部数据（dtype,维度[batch, height, width, channels]，名称）
y_=tf.placeholder(tf.int32,shape=[None,],name='y_')

def inference(input_tensor, train, regularizer):
    with tf.variable_scope('layer1-conv1'):                           #定义创建变量（层）的操作的上下文管理器
        conv1_weights = tf.get_variable("weight",[5,5,3,32],initializer=tf.truncated_normal_initializer(stddev=0.1)) #产生随机值的方法truncated_normal_initializer中可以指定随机值的mean，标准偏差和随机种子，数据类型
    #https://blog.csdn.net/u011851421/article/details/82993389?utm_medium=distribute.pc_relevant.none-task-blog-BlogCommendFromMachineLearnPai2-1.compare&depth_1-utm_source=distribute.pc_relevant.none-task-blog-BlogCommendFromMachineLearnPai2-1.compare
        conv1_biases = tf.get_variable("bias", [32], initializer=tf.constant_initializer(0.0))             #bias的初始值设为零  [32]是维度 因为filter输出是32通道所以需要在各个通道上面加偏执
        conv1 = tf.nn.conv2d(input_tensor, conv1_weights, strides=[1, 1, 1, 1], padding='SAME')         #卷积操作：strides是每一维的步长，[1 strides strides 1];padding=SAMES是考虑边界0填充，valide不考虑
        #https://blog.csdn.net/zuolixiangfisher/article/details/80528989
        relu1 = tf.nn.relu(tf.nn.bias_add(conv1, conv1_biases)) #tf.nn.relu就是把传入的序列进行relu的计算，他的参数是卷积结果是加上偏置之后 的卷积结果

    with tf.name_scope("layer2-pool1"):
        pool1 = tf.nn.max_pool(relu1, ksize = [1,2,2,1],strides=[1,2,2,1],padding="VALID")    #参数表和conv2d一样，relu1[batchsize height width channel] ksize[1 height width 1] stride[1 stride stride 1] padding

    with tf.variable_scope("layer3-conv2"):
        conv2_weights = tf.get_variable("weight",[5,5,32,64],initializer=tf.truncated_normal_initializer(stddev=0.1))
        conv2_biases = tf.get_variable("bias", [64], initializer=tf.constant_initializer(0.0))
        conv2 = tf.nn.conv2d(pool1, conv2_weights, strides=[1, 1, 1, 1], padding='SAME')
        relu2 = tf.nn.relu(tf.nn.bias_add(conv2, conv2_biases))

    with tf.name_scope("layer4-pool2"):
        pool2 = tf.nn.max_pool(relu2, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='VALID')

    with tf.variable_scope("layer5-conv3"):
        conv3_weights = tf.get_variable("weight",[3,3,64,128],initializer=tf.truncated_normal_initializer(stddev=0.1))
        conv3_biases = tf.get_variable("bias", [128], initializer=tf.constant_initializer(0.0))
        conv3 = tf.nn.conv2d(pool2, conv3_weights, strides=[1, 1, 1, 1], padding='SAME')
        relu3 = tf.nn.relu(tf.nn.bias_add(conv3, conv3_biases))

    with tf.name_scope("layer6-pool3"):
        pool3 = tf.nn.max_pool(relu3, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='VALID')

    with tf.variable_scope("layer7-conv4"):
        conv4_weights = tf.get_variable("weight",[3,3,128,128],initializer=tf.truncated_normal_initializer(stddev=0.1))
        conv4_biases = tf.get_variable("bias", [128], initializer=tf.constant_initializer(0.0))
        conv4 = tf.nn.conv2d(pool3, conv4_weights, strides=[1, 1, 1, 1], padding='SAME')
        relu4 = tf.nn.relu(tf.nn.bias_add(conv4, conv4_biases))

    with tf.name_scope("layer8-pool4"):                                                                             #最后一个池化层有点小变化，需要将池化的结果reshape
        pool4 = tf.nn.max_pool(relu4, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='VALID')                    #将池化的结果铺成一个行的列表（因为第一个arg为-1）
        nodes = 6*6*128                                                                                             #每个元素是一个6x6x128列的列表为什么是这个尺寸
        reshaped = tf.reshape(pool4,[-1,nodes])                 #利用reshape进行数组形状的转换时，一定要满足[x,y]中x×y=数组的个数。-1表示不知道这一维是多少尺寸，自己算
                                                                #这里表示把pool4reshape成不知道多少行但是nodes列（按照行优先派）
    with tf.variable_scope('layer9-fc1'):
        fc1_weights = tf.get_variable("weight", [nodes, 1024],
                                      initializer=tf.truncated_normal_initializer(stddev=0.1))
        if regularizer != None: tf.add_to_collection('losses', regularizer(fc1_weights))
        fc1_biases = tf.get_variable("bias", [1024], initializer=tf.constant_initializer(0.1))

        fc1 = tf.nn.relu(tf.matmul(reshaped, fc1_weights) + fc1_biases)
        if train: fc1 = tf.nn.dropout(fc1, 0.5)

    with tf.variable_scope('layer10-fc2'):
        fc2_weights = tf.get_variable("weight", [1024, 512],
                                      initializer=tf.truncated_normal_initializer(stddev=0.1))
        if regularizer != None: tf.add_to_collection('losses', regularizer(fc2_weights))
        fc2_biases = tf.get_variable("bias", [512], initializer=tf.constant_initializer(0.1))

        fc2 = tf.nn.relu(tf.matmul(fc1, fc2_weights) + fc2_biases)
        if train: fc2 = tf.nn.dropout(fc2, 0.5)

    with tf.variable_scope('layer11-fc3'):
        fc3_weights = tf.get_variable("weight", [512, 3],
                                      initializer=tf.truncated_normal_initializer(stddev=0.1))
        if regularizer != None: tf.add_to_collection('losses', regularizer(fc3_weights))
        fc3_biases = tf.get_variable("bias", [3], initializer=tf.constant_initializer(0.1))
        logit = tf.matmul(fc2, fc3_weights) + fc3_biases

    return logit

#---------------------------网络结束---------------------------
regularizer = tf.contrib.layers.l2_regularizer(0.0001)
logits = inference(x,False,regularizer)

#(小处理)将logits乘以1赋值给logits_eval，定义name，方便在后续调用模型时通过tensor名字调用输出tensor
b = tf.constant(value=1,dtype=tf.float32)
logits_eval = tf.multiply(logits,b,name='logits_eval') 

loss=tf.nn.sparse_softmax_cross_entropy_with_logits(logits=logits, labels=y_)
train_op=tf.train.AdamOptimizer(learning_rate=0.001).minimize(loss)
correct_prediction = tf.equal(tf.cast(tf.argmax(logits,1),tf.int32), y_)    
acc= tf.reduce_mean(tf.cast(correct_prediction, tf.float32))


#定义一个函数，按批次取数据
def minibatches(inputs=None, targets=None, batch_size=None, shuffle=False):
    assert len(inputs) == len(targets)
    if shuffle:
        indices = np.arange(len(inputs))
        np.random.shuffle(indices)
    for start_idx in range(0, len(inputs) - batch_size + 1, batch_size):
        if shuffle:
            excerpt = indices[start_idx:start_idx + batch_size]
        else:
            excerpt = slice(start_idx, start_idx + batch_size)
        yield inputs[excerpt], targets[excerpt]


#训练和测试数据，可将n_epoch设置更大一些

n_epoch=10                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           
batch_size=8
saver=tf.train.Saver()
sess=tf.Session()  
sess.run(tf.global_variables_initializer())
for epoch in range(n_epoch):
    start_time = time.time()

    #training
    train_loss, train_acc, n_batch = 0, 0, 0
    for x_train_a, y_train_a in minibatches(x_train, y_train, batch_size, shuffle=True):
        _,err,ac=sess.run([train_op,loss,acc], feed_dict={x: x_train_a, y_: y_train_a})
        train_loss += err; train_acc += ac; n_batch += 1
    print("   train loss: %f" % (np.sum(train_loss)/ n_batch))
    print("   train acc: %f" % (np.sum(train_acc)/ n_batch))

    #validation
    val_loss, val_acc, n_batch = 0, 0, 0
    for x_val_a, y_val_a in minibatches(x_val, y_val, batch_size, shuffle=False):
        err, ac = sess.run([loss,acc], feed_dict={x: x_val_a, y_: y_val_a})
        val_loss += err; val_acc += ac; n_batch += 1
    print("   validation loss: %f" % (np.sum(val_loss)/ n_batch))
    print("   validation acc: %f" % (np.sum(val_acc)/ n_batch))
saver.save(sess,model_path)
sess.close()