
from skimage import io,transform
import glob
import os
import tensorflow as tf
import numpy as np
import time
import pandas as pd#excel操作不能用于字符串
import xlsxwriter#excel操作

path='C:/Users/DELL/Desktop/nchuMSC/realtest/'

#path='H:/Dataset/stool/Color/NewTensorflow/allpre1/'
#path='H:/Dataset/Palmprint/3Dpalmprint3/'

#将所有的图片resize成100*100
w=100
h=100
c=3


                                                                                                                        #读取图片
def read_img(path):
    imgs = []
    labels = []
    location = []
    os.listdir()
    # os.listdir(path)方法用于返回指定的文件夹包含的文件或文件夹的名字的列表。
    cate=[path+x for x in os.listdir(path) if os.path.isdir(path+x)]
    # cate = []
    # for x in os.listdir(path):  # 读取文件夹里所有文件夹的路径，赋值到cate列表
    #     if (os.path.isdir(path + '\\' + x)):os.path.isdir()用于判断对象是否为一个目录
    #         cate.append(path + '\\' + x)

    # 给文件夹排序号，0是0文件夹，1是1文件夹...
    for idx,folder in enumerate(cate): #enumerate的输出通常为序号和对应的元素。
        # 遍历文件夹内的*.jpg文件（路径）
        for im in glob.glob(folder+'/*.png'):#改变图片类型
            print('reading the images:%s'%(im))
            # 读取jpg文件
            img=io.imread(im)
            # 把图片转换为彩色(彩色是3维，黑白是2维)
            img=transform.resize(img,(w,h,c))
            # 追加到数组imgs
            imgs.append(img)
            # 追加到数组labels
            labels.append(idx)

            location.append(im)
    # 将数组转化为矩阵
    return np.asarray(imgs,np.float32),np.asarray(labels,np.int32),location
data,label,location=read_img(path) #data 和label                                 应该是是两个array


num_example=data.shape[0] #通过，shape[0]来访问tensor第一维的大小         num_example在这里是一个数字。

arr=np.arange(num_example)
# 随机打乱顺序函数，多维矩阵中，只对第一维做打乱顺序操作。
np.random.shuffle(arr)
# 因为arr现在是一维的随机化的np矩阵，用它可以覆盖掉原数据的第一维，也就是重新给data排序
data=data[arr]
label=label[arr]                                                      #data和label现在是两个乱序array


#将所有数据分为训练集和验证集
# ratio=0.5
# 图片总数*想要取走百分之多少，并且取整，然后赋予s
# s=np.int(num_example*ratio)

# x_train=data[:s]                                                                                                        #数据分割
# y_train=label[:s]
# x_val=data[s:]
# y_val=label[s:]


PATH='G:/nchuMsc\exp/wjhF5ex1/'
gpu_options = tf.GPUOptions(per_process_gpu_memory_fraction=0.5)
sess = tf.Session(config=tf.ConfigProto(gpu_options=gpu_options, log_device_placement=True))
tf.saved_model.loader.load(sess,[tf.saved_model.tag_constants.TRAINING],PATH)#PATH还是路径                               #加载网络

x = sess.graph.get_tensor_by_name('x:0')#传入的参数会在后文讲到的                                      #加载输入和其他的关键节点
y_= sess.graph.get_tensor_by_name('y_:0')
output = sess.graph.get_tensor_by_name('dense_2/BiasAdd:0')#需要观察output的值

# sess.run(output, {x: x_val, y_: y_val}) # 大括号的内容就是feed_dict了，使用方法类似于占位符
predict=tf.cast(tf.argmax(sess.run(output,{x: data, y_: label}),1),tf.int32)
# print("output",output)#观察output的值 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

test=sess.run(output,{x: data, y_: label})
print(test[2])                                                                            #output是全链接的结果(?,8) 8是因为logits层有units=8
#
print(sess.run(predict,{x: data, y_: label}))                                                                           #predict是判定为哪个类(?,17):我的结果
#
print(label)                                                                                                            #desired result (?,17):理论值
#print(location)#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
pselabel=sess.run(predict,{x: data, y_: label})

locationdata=location
psedata=pselabel.tolist();
zhixindu=test.tolist()

#写入excel locationdata
xl = xlsxwriter.Workbook(r'G:\nchuMsc\exp\stool_prepro\pselabeltest.xlsx')
sheet = xl.add_worksheet('sheet1')
x=1
sheet.write_string("B%d" % x, "源路径" )
sheet.write_string("A%d" % x, "伪标签" )
sheet.write_string("D%d" % x, "可能性" )
for i in range(len(locationdata)):
    x+=1#A的序号是从X+1开始进行编号
    sheet.write_string("B%d" % x, "%s" % locationdata[i])
    sheet.write_string("A%d" % x, "%s" % psedata[i])
    sheet.write_string("D%d" % x, "%s" % zhixindu[i])
    # print(locationdata[i])#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
xl.close()
# #写入excel pselabeldata
# pselabeldata = pd.DataFrame(pselabel)
# writer = pd.ExcelWriter('E:/nchugraduation\planI_stoolnet\stool_prepro\pselabel.xlsx')		# 写入Excel文件
# pselabeldata.to_excel(writer, 'sheet1', float_format='%.5f', startcol=1)		# ‘page_1’是写入excel的sheet名
# writer.save()
# writer.close()

sess.close()


