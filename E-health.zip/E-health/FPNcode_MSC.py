class FPN(tf.keras.Model):
    def __init__(self, block, num_blocks):
        super(FPN, self).__init__()
        self.in_channels = 64

        self.conv1 = tf.keras.layers.Conv2D(64, 7, 2, padding="same", use_bias=False)
        self.bn1 = tf.keras.layers.BatchNormalization()

        # Bottom --> up layers
        self.layer1 = self._make_layer(block, 64, num_blocks[0], stride=1)
        self.layer2 = self._make_layer(block, 128, num_blocks[1], stride=2)
        self.layer3 = self._make_layer(block, 256, num_blocks[2], stride=2)
        self.layer4 = self._make_layer(block, 512, num_blocks[3], stride=2)

        # Smooth layers
        self.smooth1 = tf.keras.layers.Conv2D(256, 3, 1, padding="same")
        self.smooth2 = tf.keras.layers.Conv2D(256, 3, 1, padding="same")
        self.smooth3 = tf.keras.layers.Conv2D(256, 3, 1, padding="same")
        self.smooth4 = tf.keras.layers.Conv2D(256, 3, 1, padding="same")

        # Lateral layers
        self.lateral_layer1 = tf.keras.layers.Conv2D(256, 1, 1, padding="valid")
        self.lateral_layer2 = tf.keras.layers.Conv2D(256, 1, 1, padding="valid")
        self.lateral_layer3 = tf.keras.layers.Conv2D(256, 1, 1, padding="valid")
        self.lateral_layer4 = tf.keras.layers.Conv2D(256, 1, 1, padding="valid")

    def _make_layer(self, block, out_channels, num_blocks, stride):
        strides = [stride] + [1] * (num_blocks - 1)
        layers = []
        for stride in strides:
            layers.append(block(self.in_channels, out_channels, stride))
            self.in_channels = out_channels
        return tf.keras.Sequential(layers)

    def _upsample_add(self, x, y):
        _, H, W, C = y.shape
        return tf.image.resize(x, size=(H, W), method="bilinear")

    def call(self, x, training=False):
        C1 = tf.nn.relu(self.bn1(self.conv1(x), training=training))
        C1 = tf.nn.max_pool2d(C1, ksize=3, strides=2, padding="SAME")

        # Bottom --> up
        C2 = self.layer1(C1, training=training)
        C3 = self.layer2(C2, training=training)
        C4 = self.layer3(C3, training=training)
        C5 = self.layer4(C4, training=training)

        # Top-down
        M5 = self.lateral_layer1(C5)
        M4 = self._upsample_add(M5, self.lateral_layer2(C4))
        M3 = self._upsample_add(M4, self.lateral_layer3(C3))
        M2 = self._upsample_add(M3, self.lateral_layer4(C2))

        # Smooth
        P5 = self.smooth1(M5)
        P4 = self.smooth2(M4)
        P3 = self.smooth3(M3)
        P2 = self.smooth4(M2)

        return P2, P3, P4, P5