from skimage import io, transform
import glob
import os
import tensorflow as tf
import numpy as np
import time
import matplotlib.pyplot as plt
# import pylab as pl
# from mpl_toolkits.axes_grid1.inset_locator import inset_axes
import xlsxwriter  # excel操作

# import os
# os.environ["CUDA_VISIBLE_DEVICES"] = "-1"

# os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
# 保证程序中的GPU序号是和硬件中的序号是相同的

# os.environ['CUDA_VISIBLE_DEVICES'] = "0,1"

# path='E:/nchugraduation\planI_stoolnet\stool_prepro\大库新35/'#第一次训练用这个
path = 'E:/nchugraduation\planI_stoolnet\颜色和性状\颜色/'  # 第二次训练用这个（这是一个包含伪标签的路径），千万千万要记得把后面的模型保存路径给改一下

# path='H:/Dataset/stool/Color/NewTensorflow/allpre1/'
# path='H:/Dataset/Palmprint/3Dpalmprint3/'

# 将所有的图片resize成100*100
w = 100
h = 100
c = 3


# 读取图片
def read_img(path):
    imgs = []
    labels = []
    os.listdir()
    # os.listdir(path)方法用于返回指定的文件夹包含的文件或文件夹的名字的列表。
    cate = [path + x for x in os.listdir(path) if os.path.isdir(path + x)]
    # cate = []
    # for x in os.listdir(path):  # 读取文件夹里所有文件夹的路径，赋值到cate列表
    #     if (os.path.isdir(path + '\\' + x)):os.path.isdir()用于判断对象是否为一个目录
    #         cate.append(path + '\\' + x)

    # 给文件夹排序号，0是0文件夹，1是1文件夹...
    for idx, folder in enumerate(cate):  # enumerate的输出通常为序号和对应的元素。
        # 遍历文件夹内的*.jpg文件（路径）
        for im in glob.glob(folder + '/*.jpg'):
            print('reading the images:%s' % (im))
            # 读取jpg文件
            img = io.imread(im)
            # 把图片转换为彩色(彩色是3维，黑白是2维)
            img = transform.resize(img, (w, h, c))
            # 追加到数组imgs
            imgs.append(img)
            # 追加到数组labels
            labels.append(idx)
    # 将数组转化为矩阵
    return np.asarray(imgs, np.float32), np.asarray(labels, np.int32)


data, label = read_img(path)  # data 和label                                 应该是是两个array

# 打乱顺序

# 这个data是读取图片的合计，其中第一维就是图片的序号，也就是图片的总量
num_example = data.shape[0]  # 通过，shape[0]来访问tensor第一维的大小         num_example在这里是一个数字。
# np.arange(起始值，终止值，步长) 与arange(起始值，终止值，步长)
# 不同之处是np.arange的参数可以是小数
arr = np.arange(num_example)
# 随机打乱顺序函数，多维矩阵中，只对第一维做打乱顺序操作。
np.random.shuffle(arr)
# 因为arr现在是一维的随机化的np矩阵，用它可以覆盖掉原数据的第一维，也就是重新给data排序
data = data[arr]
label = label[arr]  # data和label现在是两个乱序array

# 将所有数据分为训练集和验证集
ratio = 0.75
# 图片总数*想要取走百分之多少，并且取整，然后赋予s
s = np.int(num_example * ratio)
# 以下是把图片分为“训练用图片”“训练用图片的标签”，“验证用图片”“验证用图片的标签”。
# 其中[:s]或[s:]是列表的切片，表示由开始到s，或由s到最后。
x_train = data[:s]  # 数据分割
y_train = label[:s]
x_val = data[s:]
y_val = label[s:]
# 定义网络结构

# -----------------构建网络----------------------
# 占位符
# 为数据与标签设立两个存放空间
# 所以placeholder()函数是在神经网络构建graph的时候在模型中的占位，此时并没有把要输入的数据传入模型，
# 它只会分配必要的内存。                         等建立session，在会话中，运行模型的时候通过feed_dict()函数向占位符喂入数据。


#
x = tf.placeholder(tf.float32, shape=[None, w, h, c],
                   name='x')  # (数据类型，数据形状：3维，名称)                                  #定义网络结构
y_ = tf.placeholder(tf.int32, shape=[None, ], name='y_')

# 第一个卷积层（100——>50)
conv1 = tf.layers.conv2d(
    inputs=x,  # 输入图片
    filters=32,  # 32个过滤器
    kernel_size=[5, 5],
    padding="same",  # 填充方式
    activation=tf.nn.relu,  # 激活函数
    kernel_initializer=tf.truncated_normal_initializer(stddev=0.01))
# 池化层
pool1 = tf.layers.max_pooling2d(inputs=conv1, pool_size=[2, 2], strides=2)

# 第二个卷积层(50->25)
conv2 = tf.layers.conv2d(
    inputs=pool1,
    filters=64,
    kernel_size=[5, 5],
    padding="same",
    activation=tf.nn.relu,
    kernel_initializer=tf.truncated_normal_initializer(stddev=0.01))
pool2 = tf.layers.max_pooling2d(inputs=conv2, pool_size=[2, 2], strides=2)

# 第三个卷积层(25->12)
conv3 = tf.layers.conv2d(
     inputs=pool2,
     filters=128,
     kernel_size=[3, 3],
     padding="same",
     activation=tf.nn.relu,
    kernel_initializer=tf.truncated_normal_initializer(stddev=0.01))
pool3 = tf.layers.max_pooling2d(inputs=conv3, pool_size=[2, 2], strides=2)

# # 第四个卷积层(12->6)
# conv4 = tf.layers.conv2d(
#     inputs=pool3,
#     filters=128,
#     kernel_size=[3, 3],
#     padding="same",
#     activation=tf.nn.relu,
#     kernel_initializer=tf.truncated_normal_initializer(stddev=0.01))
# pool4 = tf.layers.max_pooling2d(inputs=conv4, pool_size=[2, 2], strides=2)

re1 = tf.reshape(pool3, [-1, 12 * 12 * 128])                  #修改网络层数这里需要改

# 全连接层
dense2 = tf.layers.dense(inputs=re1,
                         units=4608,
                         activation=tf.nn.relu,
                         kernel_initializer=tf.truncated_normal_initializer(stddev=0.01),
                         kernel_regularizer=tf.contrib.layers.l2_regularizer(0.003))
dense3 = tf.layers.dense(inputs=dense2,
                         units=1024,
                         activation=tf.nn.relu,
                         kernel_initializer=tf.truncated_normal_initializer(stddev=0.01),
                         kernel_regularizer=tf.contrib.layers.l2_regularizer(0.003))

logits = tf.layers.dense(inputs=dense3,
                         units=8,
                         activation=None,
                         kernel_initializer=tf.truncated_normal_initializer(stddev=0.01),
                         kernel_regularizer=tf.contrib.layers.l2_regularizer(0.003))
# 网络代码

# ------------------------ ---网络结束---------------------------


# with tf.name_scope('traninloss') as scope:

#    loss=tf.losses.sparse_softmax_cross_entropy(labels=y_,logits=logits)
#    loss1= tf.summary.scalar('trainloss',loss)
with tf.name_scope('trainloss') as scope:  # 定义loss
    # 计算logits 和 labels 之间的稀疏softmax 交叉熵 这个是计算误差率
    loss = tf.losses.sparse_softmax_cross_entropy(labels=y_, logits=logits)
    loss1 = tf.summary.scalar('trainloss', loss)
with tf.name_scope('testloss') as scope:
    loss2 = tf.losses.sparse_softmax_cross_entropy(labels=y_, logits=logits)
    loss3 = tf.summary.scalar('testloss', loss2)
with tf.name_scope('output') as scope:  # 这个地方是我加的
    predict = tf.cast(tf.argmax(logits, 1), tf.int32)

# tf.train.AdamOptimizer 优化器中的梯度优化函数，
# 作用是依据learning_rate步长，来最小化loss误差率。
train_op = tf.train.AdamOptimizer(learning_rate=0.001).minimize(loss)  # 定义优化器，初始学习率，等#加了一个decay
# train_op = tf.train.MomentumOptimizer(0.001,0.9, use_locking=False, name='Momentum', use_nesterov=False).minimize(loss)
# tf.argmax(vector, 1)：返回的是vector中的最大值的索引号，
# 如果vector是一个向量，那就返回一个值，如果是一个矩阵，那就返回一个向量，
# 这个向量的每一个维度都是相对应矩阵行的最大值元素的索引号。

# tf.cast(x, dtype, name=None)
# 此函数是类型转换函数
# 参数
# x：输入
# dtype：转换目标类型
# name：名称
# 返回：Tensor

# tf.equal(A, B)是对比这两个矩阵或者向量的相等的元素，如果是相等的那就返回True，反正返回False，
# 返回的值的矩阵维度和A是一样的，返回的也是一个矩阵、向量、列表，里面都是true和false。

# 这一行的意思，大概是，通过以上三个函数，对比处理后的logits值和labels值，然后得出一个判断表单

correct_prediction = tf.equal(tf.cast(tf.argmax(logits, 1), tf.int32), y_)  # 定义预测的结果
# acc= tf.reduce_mean(tf.cast(correct_prediction, tf.float32))

# 这个......大概是在计算准确率
# 求平均值tf.reduce_mean(input_tensor, reduction_indices=None, keep_dims=False, name=None)
# 参数1--input_tensor:待求值的tensor。
# 参数2--reduction_indices:在哪一维上求解。
# 参数（3）（4）可忽略

# tf.summary.scalar('accuracy', acc)

with tf.name_scope('trainacc') as scope:  # 定义acc
    acc = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
    acc1 = tf.summary.scalar('trainacc', acc)
with tf.name_scope('testacc') as scope:
    acc2 = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
    acc3 = tf.summary.scalar('testacc', acc2)


# with tf.name_scope('labekacc') as scope:                                               #这个地方是我加的
#     acc4= tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
#     acc5 = tf.summary.scalar('labekacc',acc4)


# 定义一个函数，按批次取数据

# 四个参数是：训练数据，测试数据，用户输入的每批训练的数据数量，
# shuffle是洗牌的意思，这里表示是否开始随机。
def minibatches(inputs=None, targets=None, batch_size=None, shuffle=False):
    # assert断言机制，如果后面的表达式为真，则直接抛出异常。在这里的意思,大概就是:样本和标签数量要对上
    assert len(inputs) == len(targets)
    if shuffle:
        # 生成一个np.arange可迭代长度是len(训练数据),也就是训练数据第一维数据的数量
        # (就是训练数据的数量，训练图片的数量)
        indices = np.arange(len(inputs))
        # np.random.shuffle打乱arange中的顺序，使其随机循序化，如果是数组，只打乱第一维。
        np.random.shuffle(indices)
    # 这个range(初始值为0，终止值为[训练图片数-每批训练图片数+1]，步长是[每批训练图片数])：
    # 例(0[起始值],80[训练图片数]-20[每批训练图片数],20[每批训练图片数]),也就是(0,60,20)
    # 当循环到60时,会加20到达80的训练样本.
    for start_idx in range(0, len(inputs) - batch_size + 1, batch_size):
        # 如果shuffle为真,将indices列表,切片(一批)赋值给excerpt
        if shuffle:
            excerpt = indices[start_idx:start_idx + batch_size]
            # 如果shuffle为假,将slice()函数(切片函数),实例化,初始值为start_idx,结束为止为start_idx + batch_size
            # (也就是根据上一批起始,算出本批结束的位置.),间距为默认.
        else:
            excerpt = slice(start_idx, start_idx + batch_size)

        yield inputs[excerpt], targets[excerpt]
        # yield常见用法：该关键字用于函数中会把函数包装为generator。然后可以对该generator进行迭代: for x in fun(param).
        # 按照我的理解，可以把yield的功效理解为暂停和播放。
        # 在一个函数中，程序执行到yield语句的时候，程序暂停，返回yield后面表达式的值，在下一次调用的时候，从yield语句暂停的地方继续执行，如此循环，直到函数执行完。
        # 此处,就是返回每次循环中 从inputs和targets列表中,截取的 经过上面slice()切片函数定义过的 数据.
        # (最后的shuffle变 量，决定了样本是否随机化)


# 训练和测试数据，可将n_epoch设置更大一些

n_epoch = 100  # 记得改回来
batch_size = 4  # 记得改回来
# 创建保存点，并进入计算图流程   还有限制gpu，我的电脑没有这句话就各种死
gpu_options = tf.GPUOptions(per_process_gpu_memory_fraction=0.5)
# sess=tf.InteractiveSession()
# sess.run(tf.global_variables_initializer())
sess = tf.Session(config=tf.ConfigProto(gpu_options=gpu_options, log_device_placement=True))
writer = tf.summary.FileWriter("./stoolstool/", sess.graph)  # 这个保存的东西有什么用

sess.run(tf.global_variables_initializer())  # 初始化整个流

# 开始训练：第一个for循环，是总体训练的次数。                                                  开始训练
# 第一个for子循环是训练样本循环，当其结束也就是训练样本被整体遍历了一次。
# 第二个也一样，不过是验证样本。

# 训练多少遍，FLAGS.epoch是用户输入的，比如是5，也就是把样本遍历5遍
trainloss = []
valloss = []
trainacc = []
valacc = []
epochseq = []
for epoch in range(n_epoch):
    start_time = time.time()
    print("  第 %f 轮训练" % (1 + epoch))
    # training
    ### 单次训练部分  此处for循环结束之日，就是训练样本遍历了一遍之时......
    # 先定义下训练误差，训练识别率，训练批次
    train_loss, train_acc, n_batch = 0, 0, 0
    for x_train_a, y_train_a in minibatches(x_train, y_train, batch_size, shuffle=True):
        # 遍历minibatches函数，因为这个函数中有yield关键字，每次for，会获取到不同的批次，直到训练样本集合身体被掏空。
        # 注意，这里shuffle为True，样本是随机的。
        _, err, ac = sess.run([train_op, loss, acc],
                              feed_dict={x: x_train_a, y_: y_train_a})  # train_op在前面有定义     这里是train一个minibatch然后返沪loss
        # 其中merged是train_summary计算图；train_op是梯度优化方法，err接收的loss是误差率；ac接收的acc是准确率。
        # 后面的x和y_就是每批的数据和标签。
        # 统计误差率、准确率、批次
        train_loss += err;
        train_acc += ac;
        n_batch += 1
    result = sess.run(loss1, feed_dict={x: x_train, y_: y_train})
    result1 = sess.run(acc1, feed_dict={x: x_train, y_: y_train})
    writer.add_summary(result, epoch)
    writer.add_summary(result1, epoch)
    print("   train loss: %f" % (train_loss / n_batch))  # n_batch有可能是0
    print("   train acc: %f" % (train_acc / n_batch))
    trainloss.append(train_loss / n_batch)  # 保存loss用于画曲线
    trainacc.append(train_acc / n_batch)  # 保存acc用于画曲线
    epochseq.append(epoch)  # 保存acc用于画曲线
    # validation
    ### 单次验证部分   具体和上面雷同，下面是计算的测试数据，不用梯度优化了
    val_loss, val_acc, n_batch = 0, 0, 0
    for x_val_a, y_val_a in minibatches(x_val, y_val, batch_size, shuffle=False):
        err, ac = sess.run([loss2, acc2], feed_dict={x: x_val_a, y_: y_val_a})
        val_loss += err;
        val_acc += ac;
        n_batch += 1
        output = sess.run(predict, feed_dict={x: x_val_a, y_: y_val_a})
        print(predict)

        # one=tf.constant(-1,dtype = tf.float32)                                                         #这里是我加的
        # logits_sub1=tf.add(logits, one)
        # with tf.Session() as sess:
        #     print(sess.run(logits_sub1))
    result2 = sess.run(loss3, feed_dict={x: x_val, y_: y_val})
    result3 = sess.run(acc3, feed_dict={x: x_val, y_: y_val})
    writer.add_summary(result2, epoch)
    writer.add_summary(result3, epoch)
    print("   validation loss: %f" % (val_loss / n_batch))  # 每一个loss和acc算出来都是通过循环把每个minibatch上的结果累加然后厨艺n_batch
    print("   validation acc: %f" % (val_acc / n_batch))
    valloss.append(val_loss / n_batch)  # 保存loss用于画曲线
    valacc.append(val_acc / n_batch)  # 保存acc用于画曲线
    epochseq.append(epoch)  # 保存acc用于画曲线

# %%

# savePATH = 'E:/nchugraduation\planI_stoolnet\stool\modelstool/'#这里保存的是第一次训练结果，每次训练之前千万千万要check一下这个路径不存在上次的@200epoch acc85%
savePATH = 'G:/nchuMsc\exp/3'  # 这里保存的是伪标签扩充之后的训练结果
builder = tf.saved_model.builder.SavedModelBuilder(savePATH)  # PATH是保存路径                                           #保存
builder.add_meta_graph_and_variables(sess,
                                     [tf.saved_model.tag_constants.TRAINING])  # 保存整张网络及其变量，这种方法是可以保存多张网络的，在此不作介绍，可自行了解
builder.save()  # 完成保存
# train_loss
xl = xlsxwriter.Workbook(r'G:\nchuMsc\exp\stool_prepro\msctrainloss1conv3.xlsx')
sheet = xl.add_worksheet('sheet1')
x = 1
sheet.write_string("B%d" % x, "loss")
sheet.write_string("A%d" % x, "epoch")
for i in range(len(trainloss)):
    x += 1  # A的序号是从X+1开始进行编号
    sheet.write_string("B%d" % x, "%s" % trainloss[i])
    sheet.write_string("A%d" % x, "%s" % epochseq[i])
# train——acc
xl.close()
xl = xlsxwriter.Workbook(r'G:\nchuMsc\exp\stool_prepro\msctrainacc1conv3.xlsx')
sheet = xl.add_worksheet('sheet1')
x = 1
sheet.write_string("B%d" % x, "acc")
sheet.write_string("A%d" % x, "epoch")
for i in range(len(trainacc)):
    x += 1  # A的序号是从X+1开始进行编号
    sheet.write_string("B%d" % x, "%s" % trainacc[i])
    sheet.write_string("A%d" % x, "%s" % epochseq[i])

xl.close()

# val——loss
xl = xlsxwriter.Workbook(r'G:\nchuMsc\exp\stool_prepro\mscvalloss1conv3.xlsx')
sheet = xl.add_worksheet('sheet1')
x = 1
sheet.write_string("B%d" % x, "loss")
sheet.write_string("A%d" % x, "epoch")
for i in range(len(valloss)):
    x += 1  # A的序号是从X+1开始进行编号
    sheet.write_string("B%d" % x, "%s" % valloss[i])
    sheet.write_string("A%d" % x, "%s" % epochseq[i])

xl.close()

# val——acc
xl = xlsxwriter.Workbook(r'G:\nchuMsc\exp\stool_prepro\mscvalacc1conv3.xlsx')
sheet = xl.add_worksheet('sheet1')
x = 1
sheet.write_string("B%d" % x, "acc")
sheet.write_string("A%d" % x, "epoch")
for i in range(len(valacc)):
    x += 1  # A的序号是从X+1开始进行编号
    sheet.write_string("B%d" % x, "%s" % valacc[i])
    sheet.write_string("A%d" % x, "%s" % epochseq[i])

xl.close()
sess.close()