from skimage import io, transform
from stool import FPNcode_Msc
import glob
import os
import tensorflow as tf
import numpy as np
import time
import matplotlib.pyplot as plt

import xlsxwriter  # excel操作

path = 'E:/nchugraduation\planI_stoolnet\颜色和性状\颜色/'


w = 100
h = 100
c = 3


# 读取图片
def read_img(path):
    imgs = []
    labels = []
    os.listdir()

    cate = [path + x for x in os.listdir(path) if os.path.isdir(path + x)]

    for idx, folder in enumerate(cate):

        for im in glob.glob(folder + '/*.jpg'):
            print('reading the images:%s' % (im))

            img = io.imread(im)

            img = transform.resize(img, (w, h, c))

            imgs.append(img)

            labels.append(idx)

    return np.asarray(imgs, np.float32), np.asarray(labels, np.int32)


data, label = read_img(path)


num_example = data.shape[0]

arr = np.arange(num_example)

np.random.shuffle(arr)

data = data[arr]
label = label[arr]


ratio = 0.75

s = np.int(num_example * ratio)

x_train = data[:s]
y_train = label[:s]
x_val = data[s:]
y_val = label[s:]
# 定义网络结构

# -----------------构建网络----------------------

x = tf.placeholder(tf.float32, shape=[None, w, h, c],
                   name='x')  # (数据类型，数据形状：3维，名称)                                  #定义网络结构
y_ = tf.placeholder(tf.int32, shape=[None, ], name='y_')

# 第一个卷积层（100——>50)
conv1 = tf.layers.conv2d(
    inputs=x,  # 输入图片
    filters=32,  # 32个过滤器
    kernel_size=[5, 5],
    padding="same",  # 填充方式
    activation=tf.nn.relu,  # 激活函数
    kernel_initializer=tf.truncated_normal_initializer(stddev=0.01))
# 池化层
pool1 = tf.layers.max_pooling2d(inputs=conv1, pool_size=[2, 2], strides=2)

# 第二个卷积层(50->25)
conv2 = tf.layers.conv2d(
    inputs=pool1,
    filters=64,
    kernel_size=[5, 5],
    padding="same",
    activation=tf.nn.relu,
    kernel_initializer=tf.truncated_normal_initializer(stddev=0.01))
pool2 = tf.layers.max_pooling2d(inputs=conv2, pool_size=[2, 2], strides=2)

# 第三个卷积层(25->12)
conv3 = tf.layers.conv2d(
     inputs=pool2,
     filters=128,
     kernel_size=[3, 3],
     padding="same",
     activation=tf.nn.relu,
    kernel_initializer=tf.truncated_normal_initializer(stddev=0.01))
pool3 = tf.layers.max_pooling2d(inputs=conv3, pool_size=[2, 2], strides=2)

# # 第四个卷积层(12->6)
# conv4 = tf.layers.conv2d(
#     inputs=pool3,
#     filters=128,
#     kernel_size=[3, 3],
#     padding="same",
#     activation=tf.nn.relu,
#     kernel_initializer=tf.truncated_normal_initializer(stddev=0.01))
# pool4 = tf.layers.max_pooling2d(inputs=conv4, pool_size=[2, 2], strides=2)

re1 = tf.reshape(pool3, [-1, 12 * 12 * 128])

# 全连接层
dense2 = tf.layers.dense(inputs=re1,
                         units=4608,
                         activation=tf.nn.relu,
                         kernel_initializer=tf.truncated_normal_initializer(stddev=0.01),
                         kernel_regularizer=tf.contrib.layers.l2_regularizer(0.003))
dense3 = tf.layers.dense(inputs=dense2,
                         units=1024,
                         activation=tf.nn.relu,
                         kernel_initializer=tf.truncated_normal_initializer(stddev=0.01),
                         kernel_regularizer=tf.contrib.layers.l2_regularizer(0.003))

logits = tf.layers.dense(inputs=dense3,
                         units=8,
                         activation=None,
                         kernel_initializer=tf.truncated_normal_initializer(stddev=0.01),
                         kernel_regularizer=tf.contrib.layers.l2_regularizer(0.003))
# 网络代码

# ------------------------ ---网络结束---------------------------



with tf.name_scope('trainloss') as scope:  # 定义loss

    loss = tf.losses.sparse_softmax_cross_entropy(labels=y_, logits=logits)
    loss1 = tf.summary.scalar('trainloss', loss)
with tf.name_scope('testloss') as scope:
    loss2 = tf.losses.sparse_softmax_cross_entropy(labels=y_, logits=logits)
    loss3 = tf.summary.scalar('testloss', loss2)
with tf.name_scope('output') as scope:
    predict = tf.cast(tf.argmax(logits, 1), tf.int32)


train_op = tf.train.AdamOptimizer(learning_rate=0.001).minimize(loss)

correct_prediction = tf.equal(tf.cast(tf.argmax(logits, 1), tf.int32), y_)  # 定义预测的结果



with tf.name_scope('trainacc') as scope:  # 定义acc
    acc = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
    acc1 = tf.summary.scalar('trainacc', acc)
with tf.name_scope('testacc') as scope:
    acc2 = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
    acc3 = tf.summary.scalar('testacc', acc2)


# 定义一个函数，按批次取数据

def minibatches(inputs=None, targets=None, batch_size=None, shuffle=False):

    assert len(inputs) == len(targets)
    if shuffle:

        indices = np.arange(len(inputs))

        np.random.shuffle(indices)

    for start_idx in range(0, len(inputs) - batch_size + 1, batch_size):

        if shuffle:
            excerpt = indices[start_idx:start_idx + batch_size]

        else:
            excerpt = slice(start_idx, start_idx + batch_size)

        yield inputs[excerpt], targets[excerpt]

n_epoch = 100  # 记得改回来
batch_size = 4  # 记得改回来

gpu_options = tf.GPUOptions(per_process_gpu_memory_fraction=0.5)

sess = tf.Session(config=tf.ConfigProto(gpu_options=gpu_options, log_device_placement=True))
writer = tf.summary.FileWriter("./stoolstool/", sess.graph)  # 这个保存的东西有什么用

sess.run(tf.global_variables_initializer())  # 初始化整个流

# 开始训练：第一个for循环，是总体训练的次数。                                                  开始训练

trainloss = []
valloss = []
trainacc = []
valacc = []
epochseq = []
for epoch in range(n_epoch):
    start_time = time.time()
    print("  第 %f 轮训练" % (1 + epoch))
    # training
    train_loss, train_acc, n_batch = 0, 0, 0
    for x_train_a, y_train_a in minibatches(x_train, y_train, batch_size, shuffle=True):

        _, err, ac = sess.run([train_op, loss, acc],
                              feed_dict={x: x_train_a, y_: y_train_a})

        train_loss += err;
        train_acc += ac;
        n_batch += 1
    result = sess.run(loss1, feed_dict={x: x_train, y_: y_train})
    result1 = sess.run(acc1, feed_dict={x: x_train, y_: y_train})
    writer.add_summary(result, epoch)
    writer.add_summary(result1, epoch)
    print("   train loss: %f" % (train_loss / n_batch))  # n_batch有可能是0
    print("   train acc: %f" % (train_acc / n_batch))
    trainloss.append(train_loss / n_batch)  # 保存loss用于画曲线
    trainacc.append(train_acc / n_batch)  # 保存acc用于画曲线
    epochseq.append(epoch)  # 保存acc用于画曲线
    # validation
    val_loss, val_acc, n_batch = 0, 0, 0
    for x_val_a, y_val_a in minibatches(x_val, y_val, batch_size, shuffle=False):
        err, ac = sess.run([loss2, acc2], feed_dict={x: x_val_a, y_: y_val_a})
        val_loss += err;
        val_acc += ac;
        n_batch += 1
        output = sess.run(predict, feed_dict={x: x_val_a, y_: y_val_a})
        print(predict)

    result2 = sess.run(loss3, feed_dict={x: x_val, y_: y_val})
    result3 = sess.run(acc3, feed_dict={x: x_val, y_: y_val})
    writer.add_summary(result2, epoch)
    writer.add_summary(result3, epoch)
    print("   validation loss: %f" % (val_loss / n_batch))
    print("   validation acc: %f" % (val_acc / n_batch))
    valloss.append(val_loss / n_batch)  # 保存loss用于画曲线
    valacc.append(val_acc / n_batch)  # 保存acc用于画曲线
    epochseq.append(epoch)  # 保存acc用于画曲线

# %%


savePATH = 'G:/nchuMsc\exp/3'  # 这里保存的是伪标签扩充之后的训练结果
builder = tf.saved_model.builder.SavedModelBuilder(savePATH)  # PATH是保存路径                                           #保存
builder.add_meta_graph_and_variables(sess,
                                     [tf.saved_model.tag_constants.TRAINING])  # 保存整张网络及其变量，这种方法是可以保存多张网络的，在此不作介绍，可自行了解
builder.save()  # 完成保存
# train_loss
xl = xlsxwriter.Workbook(r'G:\nchuMsc\exp\stool_prepro\msctrainloss1conv3.xlsx')
sheet = xl.add_worksheet('sheet1')
x = 1
sheet.write_string("B%d" % x, "loss")
sheet.write_string("A%d" % x, "epoch")
for i in range(len(trainloss)):
    x += 1  # A的序号是从X+1开始进行编号
    sheet.write_string("B%d" % x, "%s" % trainloss[i])
    sheet.write_string("A%d" % x, "%s" % epochseq[i])
# train——acc
xl.close()
xl = xlsxwriter.Workbook(r'G:\nchuMsc\exp\stool_prepro\msctrainacc1conv3.xlsx')
sheet = xl.add_worksheet('sheet1')
x = 1
sheet.write_string("B%d" % x, "acc")
sheet.write_string("A%d" % x, "epoch")
for i in range(len(trainacc)):
    x += 1  # A的序号是从X+1开始进行编号
    sheet.write_string("B%d" % x, "%s" % trainacc[i])
    sheet.write_string("A%d" % x, "%s" % epochseq[i])

xl.close()

# val——loss
xl = xlsxwriter.Workbook(r'G:\nchuMsc\exp\stool_prepro\mscvalloss1conv3.xlsx')
sheet = xl.add_worksheet('sheet1')
x = 1
sheet.write_string("B%d" % x, "loss")
sheet.write_string("A%d" % x, "epoch")
for i in range(len(valloss)):
    x += 1  # A的序号是从X+1开始进行编号
    sheet.write_string("B%d" % x, "%s" % valloss[i])
    sheet.write_string("A%d" % x, "%s" % epochseq[i])

xl.close()

# val——acc
xl = xlsxwriter.Workbook(r'G:\nchuMsc\exp\stool_prepro\mscvalacc1conv3.xlsx')
sheet = xl.add_worksheet('sheet1')
x = 1
sheet.write_string("B%d" % x, "acc")
sheet.write_string("A%d" % x, "epoch")
for i in range(len(valacc)):
    x += 1  # A的序号是从X+1开始进行编号
    sheet.write_string("B%d" % x, "%s" % valacc[i])
    sheet.write_string("A%d" % x, "%s" % epochseq[i])

xl.close()
sess.close()